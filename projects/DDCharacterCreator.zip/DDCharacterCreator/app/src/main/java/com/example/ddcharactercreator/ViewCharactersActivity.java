package com.example.ddcharactercreator;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ViewCharactersActivity extends AppCompatActivity {

    private static final String TAG = "ViewCharactersActivity.java";

    DatabaseHelper myDatabaseHelper;
    private Button btnEdit, btnViewData;
    private EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_characters);

        editText = (EditText) findViewById(R.id.editText);
        btnEdit = (Button) findViewById(R.id.btnEdit);
        btnViewData = (Button) findViewById(R.id.btnView);
        myDatabaseHelper = new DatabaseHelper(this);

        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newEntry = editText.getText().toString();
                if(editText.length() != 0){
                    editData(newEntry);
                    editText.setText("");
                }
                else{
                    toastMessage("You must put something in the text field!");
                }
            }
        });

        btnViewData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ViewCharactersActivity.this, ListDataActivity.class);
                startActivity(intent);
            }
        });

    }

    public void editData(String newEntry){
        boolean insertData = myDatabaseHelper.editData(newEntry);

        if(insertData){
            toastMessage("Data successfully inserted!");
        }
        else{
            toastMessage("Something went terribly wrong");
        }
    }

    //Customizable Toast
    private void toastMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

}
