package com.example.ddcharactercreator;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.concurrent.ThreadLocalRandom;

public class StatGenActivity extends AppCompatActivity {

    private Button finishCharacterButton;
    private Button rollDiceButton;
    TextView StatStr;
    TextView StatDex;
    TextView StatCon;
    TextView StatInt;
    TextView StatWis;
    TextView StatCha;
    int randStr = ThreadLocalRandom.current().nextInt(3, 18 + 1);
    int randDex = ThreadLocalRandom.current().nextInt(3, 18 + 1);
    int randCon = ThreadLocalRandom.current().nextInt(3, 18 + 1);
    int randInt = ThreadLocalRandom.current().nextInt(3, 18 + 1);
    int randWis = ThreadLocalRandom.current().nextInt(3, 18 + 1);
    int randCha = ThreadLocalRandom.current().nextInt(3, 18 + 1);
    int selectedValueId;
    TextView selectedRace;
    TextView selectedClass;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stat_gen);

        finishCharacterButton = (Button) findViewById(R.id.finishCharacterBtn);
        finishCharacterButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                FinishCharacterActivity();
            }
        });

        StatStr = (TextView) findViewById(R.id.textViewStrOutP);
        StatDex = (TextView) findViewById(R.id.textViewDexOutP);
        StatCon = (TextView) findViewById(R.id.textViewConOutP);
        StatInt = (TextView) findViewById(R.id.textViewIntellOutP);
        StatWis = (TextView) findViewById(R.id.textViewWisOutP);
        StatCha = (TextView) findViewById(R.id.textViewChaOutP);

        selectedClass = (TextView)findViewById(R.id.textViewStatClassPassOutP);
        selectedRace = (TextView)findViewById(R.id.textViewStatRacePassOutP);

        String passClass = getIntent().getStringExtra(CreateNPCActivity.EXTRA_TEXT);
        selectedClass.setText(passClass);


        rollDiceButton = (Button) findViewById(R.id.rollStatsBtn);
        rollDiceButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                StatStr.setText(String.valueOf(randStr));
                StatDex.setText(String.valueOf(randDex));
                StatCon.setText(String.valueOf(randCon));
                StatInt.setText(String.valueOf(randInt));
                StatWis.setText(String.valueOf(randWis));
                StatCha.setText(String.valueOf(randCha));
            }
        });

    }

    public void FinishCharacterActivity()
    {
        Intent intent = new Intent(this, FinishCharacterActivity.class);
        startActivity(intent);
    }
}
